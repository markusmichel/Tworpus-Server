$( document ).ready(function() {
	var xmlFiles = ["","(2)","(3)","(4)","(5)","(6)","(7)","(8)","(9)","(10)"];
	loadXMLFiles(xmlFiles);
});

function loadXMLFiles(files) {
	var parsedXml = [];
	var counter = files.length;
	for (var i = 0 ; i < files.length; i++) {
		var xmlFile = "res/tweets/tweets" + files[i] + ".xml";
		$.ajax({
			url: xmlFile,
			dataType: "xml",
			success: function(data){
				parsedXml.push(data);
				counter--;
				if (counter === 0) callsCompleted(parsedXml)
			}
		});
	}
}

function callsCompleted (parsedXml) {
		var tweets = {};
		$.each(parsedXml, function(index, value) {
			$(value).find('word').each(function(index, value) {

				var word = $(value).text();
				word = " " + word;

				if (typeof(tweets[word]) !== 'undefined'){
					tweets[word]++;
				}
				else tweets[word] = 1;

			})
		});

		tweets = sortObject(tweets);
		createBubbleChart(tweets);
}

function createBubbleChart(data) {

	var body = d3.select("body");
	var color = d3.scale.category20();

	d3.selectAll('div')
		.data(data)
		.enter().append("div")
		.style("width", function(d) { return d.value + "px"; })
		.style("background-color", function(d,i){return color(i);})
		.text(function(d) { return d.value + " " + d.key; });
}

function sortObject(obj) {
	var arr = [];
	for (var prop in obj) {
		if (obj.hasOwnProperty(prop)) {
			arr.push({
				'key': prop,
				'value': obj[prop]
			});
		}
	}
	arr.sort(function(a, b) { return b.value - a.value; });
	//arr.sort(function(a, b) { a.value.toLowerCase().localeCompare(b.value.toLowerCase()); }); //use this to sort as strings
	return arr; // returns array
}
